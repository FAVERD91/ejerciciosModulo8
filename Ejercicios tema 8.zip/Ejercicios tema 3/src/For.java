public class For {
    public static void main(String[] args) {
        for(int x = 0; x <= 3; x++)
        System.out.println("Valor de X es : " + x );
    }
}
